import { City } from './city';

describe('City', () => {
  it('should create an instance', () => {
    expect(new City()).toBeTruthy();
  });
});
